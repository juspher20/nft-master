import styled from "styled-components";
const Page = styled.article`
  position: relative;
`;

export default Page;
