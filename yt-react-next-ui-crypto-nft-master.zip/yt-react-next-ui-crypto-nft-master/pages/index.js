import Home from "../src/components/Home";

export default function Index() {
  return <Home />;
}
