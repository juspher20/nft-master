import React from "react";
import Asset from "../src/components/Asset";

export default function AssetPage() {
  return <Asset />;
}
