import React from "react";
import Profile from "../src/components/Profile";

export default function profile() {
  return <Profile />;
}
