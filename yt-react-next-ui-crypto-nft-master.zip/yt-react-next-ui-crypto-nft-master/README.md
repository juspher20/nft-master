# Youtube React NextJs UI Crypto.Com NFT Marketplace

watch how to code this step by step on my youtube channel (https://youtu.be/pbqpKrz2XLU)

designed based on crypto.com nft marketplace(https://crypto.com/nft/)

![Web 1920 – 1](https://user-images.githubusercontent.com/19800339/153836005-d2a95aa2-da87-4eca-93ca-470f16e02e22.png)
